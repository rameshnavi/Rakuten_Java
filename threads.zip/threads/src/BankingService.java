
public class BankingService {

	public void transferFunds(Account from, Account to, double amt) {
		synchronized(from) { // lock on acc1
			synchronized (to) { // lock on acc2
				from.withdraw("Withdrawer", amt);
				to.deposit("Depositor", amt);
			} // acc2 lock is released
		} // acc1 lock is released
	}
	public static void main(String[] args) {
		BankingService service = new BankingService();
		Account acc1 = new Account(12000);
		Account acc2 = new Account(8900);
		Account acc3 = new Account(7000);
		Account acc4 = new Account(2000);
		
		System.out.println("Transaction 1");
		service.transferFunds(acc1, acc2, 455);
		
		System.out.println("Transaction 2");
		service.transferFunds(acc3, acc4, 855);
		
	}

}
