
public class BankingExample {

	public static void main(String[] args) {
		Account acc = new Account(5000.00);
		TransactionThread t1 = new TransactionThread(acc, "A", TransactionType.CREDIT, 2500.00);
		TransactionThread t2 = new TransactionThread(acc, "\tB", TransactionType.DEBIT, 6000.00);
		TransactionThread t3 = new TransactionThread(acc, "\t\tC", TransactionType.CREDIT, 2000.00);

		t2.start();
		try {
			Thread.sleep(10);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		t1.start();
		t3.start(); // 4 threads are ready [ includes main ]

		// Barrier
		try {
			t1.join(); // join specifies that the caller thread has to wait for other thread to finish
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Final Balance : " + acc.getBalance());
	}

}
