package com.rakuten.prj.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/first")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); // MIME type sent to Browser/client
		PrintWriter out = response.getWriter(); // character stream to browser
		// ServletOutputStream out = response.getOutputStream(); // to write binary
		
		out.println("<html><body>");
		out.print("<h1> My first Servlet Code </h1>");
		
		out.print("<br /> Accept: " + request.getHeader("accept"));
		out.print("<br /> Accept language: " + request.getHeader("accept-language"));
		
		out.print("</body></html>");
		
	}

}
