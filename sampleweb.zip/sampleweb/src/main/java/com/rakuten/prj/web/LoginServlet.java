package com.rakuten.prj.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession ses = request.getSession(false); // get session if exists
		if (ses != null) {
			ses.invalidate(); // terminate the session [ logout ]
		}
		response.sendRedirect("index.html");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// read username / password and authenticate
		String email = request.getParameter("email"); // all users are valid

		HttpSession ses = request.getSession(); // create a session for user if not present else get existing
		ses.setAttribute("user", email);
		
		response.sendRedirect("index.html");
	}

}
