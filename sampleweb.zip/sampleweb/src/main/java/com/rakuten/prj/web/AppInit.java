package com.rakuten.prj.web;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

 
@WebListener
public class AppInit implements ServletContextListener {
	
	private int count = 100;
    public void contextDestroyed(ServletContextEvent sce)  { 
    }
	 
    public void contextInitialized(ServletContextEvent sce)  { 
         System.out.println("========> App Started!!!");
         sce.getServletContext().setAttribute("count", count);
    }
	
}
