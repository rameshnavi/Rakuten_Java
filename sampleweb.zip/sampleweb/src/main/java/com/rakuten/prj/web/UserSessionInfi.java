package com.rakuten.prj.web;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class UserSessionInfi
 *
 */
@WebListener
public class UserSessionInfi implements HttpSessionListener {

	private int userCount = 0;

	public void sessionCreated(HttpSessionEvent se) {
		userCount++;
		System.out.println("Count : " + userCount);

	}

	public void sessionDestroyed(HttpSessionEvent se) {
		userCount--;
		System.out.println("Count : " + userCount);
	}

}
