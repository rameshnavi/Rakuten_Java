package com.rakuten.prj.client;

interface Computation {
	int compute(int x, int y);
}

public class LambdaExample {

	public static void main(String[] args) {
		Computation sumCompute = new Computation() {
			@Override
			public int compute(int x, int y) {
				return x + y;
			}
		};
		
		System.out.println(sumCompute.compute(4,5));
		
		//---- Using Lambda
		Computation diffCompute = (int x, int y) -> {
			return   ( x - y);
		};
		System.out.println(diffCompute.compute(4,5));
		
		Computation mul = (x,y) -> x * y;
		System.out.println(mul.compute(4,5));
		
	}

}
