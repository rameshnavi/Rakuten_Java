package com.rakuten.prj.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.rakuten.prj.entity.Product;

public class ProductClient {

	public static void main(String[] args) {
		List<Product> products = new ArrayList<>();
		products.add(new Product(645, "Hp Laptop", 135000.00, "computer"));
		products.add(new Product(224, "iPhone", 98000.00, "mobile"));
		products.add(new Product(834, "Logitech Mouse", 600.00, "computer"));
		products.add(new Product(5, "Sony Bravia", 125000.00, "tv"));
		products.add(new Product(912, "One Plus", 32000.00, "mobile"));
		products.add(new Product(88, "HP Printer", 19000.00, "computer"));
		
//		Collections.sort(products, (p1,p2) -> (int)(p1.getPrice() - p2.getPrice()));
		
		Collections.sort(products, (p1,p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
		
		for(Product p : products) {
			System.out.println(p); // toString()
		}
		
		System.out.println("*****************");
		/*
			products.stream()
				.filter(new Predicate<Product>() {
					@Override
					public boolean test(Product p) {
						return p.getCategory().equals("mobile");
					}
				})
				.forEach(p -> System.out.println(p));
			
		 List<Product> mobiles = products.stream()
					.filter(p -> p.getCategory().equals("mobile") )
					.collect(Collectors.toList());
		*/
		 
		List<String> names = products.stream()
			.map(p -> p.getName())
			.collect(Collectors.toList());
		
		System.out.println(names);
		
		System.out.println("*********");
		
		System.out.println("Total of all products");
		
		double total = products.stream()
			.filter(p -> p.getCategory().equals("mobile") )
			.map(p -> p.getPrice())
			.reduce(0.0, (v1,v2) -> v1 +v2); // v1 -> 0.0, v2 --> 135000, v1+v2 --> v1, v2 --> 98000
		
		System.out.println(total);
		 
	}

}
