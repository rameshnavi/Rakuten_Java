package com.rakuten;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rakuten.entity.Product;
import com.rakuten.service.OrderService;

@SpringBootApplication
public class OrderappApplication implements CommandLineRunner {

	@Autowired
	private OrderService orderService;

	public static void main(String[] args) {
		SpringApplication.run(OrderappApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
//		List<Product> products = new ArrayList<>();
//		products.add(new Product(645, "Hp Laptop", 135000.00, 100));
//		products.add(new Product(224, "iPhone", 98000.00, 100));
//		products.add(new Product(834, "Logitech Mouse", 600.00, 100));
//		products.add(new Product(5, "Sony Bravia", 125000.00, 100));
//		products.add(new Product(912, "One Plus", 32000.00, 100));
//		products.add(new Product(88, "HP Printer", 19000.00, 100));
//
//		for (Product p : products) {
//			orderService.addProduct(p);
//		}
	}

}
