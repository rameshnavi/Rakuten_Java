package com.rakuten.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rakuten.entity.Product;
import com.rakuten.service.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/products")
@Api(tags = {"Product RESTful Controller"}, produces = "json", consumes = "json")
public class ProductController {
	@Autowired
	private OrderService service;
	
	@ApiOperation(value="get all products", tags = {"gets all products in JSON format"})
	@GetMapping()
	public @ResponseBody List<Product> getProducts() {
		return service.getProducts();
	}
	
	@GetMapping("/{id}")
	public @ResponseBody Product getProduct(@PathVariable("id") int id) {
		return service.getProductById(id);
	}
	
	@PostMapping()
	public ResponseEntity<Product> addProduct(@RequestBody Product p) {
		service.addProduct(p);
		return new ResponseEntity<Product>(p, HttpStatus.CREATED);
	}
}
