package com.rakuten.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rakuten.entity.Order;
import com.rakuten.service.OrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
	@Autowired
	private OrderService orderService;
	
	@GetMapping()
	public @ResponseBody List<Order> getOrders() {
		return orderService.getOrders();
	}
	
	@PostMapping()
	public ResponseEntity<Order> addOrder(@RequestBody Order o) {
		orderService.addOrder(o);
		return new ResponseEntity<Order>(o, HttpStatus.CREATED);
	}
}
