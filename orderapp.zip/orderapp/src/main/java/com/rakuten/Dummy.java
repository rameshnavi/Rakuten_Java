package com.rakuten;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rakuten.entity.Product;

public class Dummy {

	public static void main(String[] args) throws Exception {
		Product p = new Product(645, "Hp Laptop", 135000.00, 100);
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(System.out, p);
	}

}
