package com.rakuten;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Listener {

	@JmsListener(destination = "springbootQueue")
	public void receiveMessage(final Message msg) throws JMSException {
		System.out.println("Received message " + msg);
		TextMessage tm = (TextMessage) msg;
	}

}