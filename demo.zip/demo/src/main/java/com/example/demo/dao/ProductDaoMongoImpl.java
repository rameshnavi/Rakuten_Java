package com.example.demo.dao;

import org.springframework.stereotype.Repository;

@Repository()
public class ProductDaoMongoImpl implements ProductDao {

	@Override
	public void addProduct() {
		System.out.println("Stored in mongoDB !!!");
	}

}
