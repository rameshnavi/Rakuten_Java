package com.example.demo.api;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.afford;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.MockService;

@RestController
public class EmployeeController {

	@Autowired
	MockService mockService;
	
	@GetMapping("api/employees") 
	public CollectionModel<EntityModel<Employee>> getEmployees() {
		List<Employee> emps = mockService.getEmployees();
		List<EntityModel<Employee>> empModelList = new ArrayList<EntityModel<Employee>>(); 
		for(Employee e : emps) {
				EntityModel<Employee> empmodel = new EntityModel<>(e);
				empmodel.add(
						 linkTo(methodOn(EmployeeController.class)
						.getEmployee(e.getId())).withSelfRel()
						.andAffordance(afford(methodOn(EmployeeController.class).updateEmployee(e.getId(), null)))
						.andAffordance(afford(methodOn(EmployeeController.class).deleteEmployee(e.getId()))));
				
				empModelList.add(empmodel);
		}
		CollectionModel<EntityModel<Employee>> empModels =	new CollectionModel<EntityModel<Employee>>(empModelList);	
		return empModels;
	}
	
	@GetMapping("api/employees/{id}")
	public EntityModel<Employee> getEmployee(@PathVariable("id") int id) {
		return new EntityModel<>(mockService.getEmployees().stream().filter(e -> e.getId() == id)
				.findFirst().get());
		
	}
	
	@PutMapping("api/employees/{id}")
	public ResponseEntity<String> updateEmployee(@PathVariable("id") int id, @RequestBody Employee e) {
		// add
		return new ResponseEntity<String>(HttpStatus.CREATED);
	}
	@DeleteMapping("api/employees/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") int id) {
		// delete employee
		return new ResponseEntity<String>(HttpStatus.OK);
	}
}


