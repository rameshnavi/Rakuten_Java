package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Department;
import com.example.demo.model.Employee;

@Service
public class MockService {

	public List<Employee> getEmployees() {
		return List.of(new Employee(1, "Tim"), new Employee(2,"Roger"), new Employee(3,"Lee"));
	}
	
	public List<Department> getDepartments() {
		Department d1 = new Department();
		d1.setName("SE");
		d1.getEmployees().add(getEmployees().get(1));
		
		Department d2 = new Department();
		d2.setName("ACTS");
		d2.getEmployees().add(getEmployees().get(0));
		d2.getEmployees().add(getEmployees().get(2));
		
		return List.of(d1,d2);
	}
}
