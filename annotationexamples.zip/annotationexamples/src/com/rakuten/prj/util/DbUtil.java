package com.rakuten.prj.util;

import java.lang.reflect.Method;

import com.rakuten.prj.entity.Column;
import com.rakuten.prj.entity.Table;

public class DbUtil {
	// Employee.class, Product.class
	public static String generateCreateStatement(Class clzz) {
		StringBuilder sb = new StringBuilder();
		Table table = (Table) clzz.getAnnotation(Table.class);
		if (table != null) {
			sb.append("create table ");
			sb.append(table.name());
			sb.append("("); // create table emps (

			Method[] methods = clzz.getMethods();
			for (Method m : methods) {
				if (m.getName().startsWith("get")) {
					Column col = m.getAnnotation(Column.class);
					if (col != null) {
						sb.append(col.name());  
						sb.append(" ");
						sb.append(col.type()); 
						sb.append(","); // create table emps ( emp_id NUMERIC(12), email VARCHAR(255), 
					}
				}
			}
			sb.setCharAt(sb.lastIndexOf(","), ')');
		}
		return sb.toString(); // create table emps ( emp_id NUMERIC(12), email VARCHAR(255))
	}
}
