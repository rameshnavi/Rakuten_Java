package com.rakuten.prj.entity;

@Table(name = "emps")
public class Employee {
	private int id;

	private String email;

	@Column(name = "emp_id", type = "NUMERIC(12)")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "email")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
