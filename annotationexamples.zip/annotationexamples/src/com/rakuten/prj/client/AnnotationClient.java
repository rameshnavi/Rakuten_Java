package com.rakuten.prj.client;

import com.rakuten.prj.entity.Employee;
import com.rakuten.prj.util.DbUtil;

public class AnnotationClient {

	public static void main(String[] args) {
		String SQL = DbUtil.generateCreateStatement(Employee.class);
		System.out.println(SQL);
	}

}
