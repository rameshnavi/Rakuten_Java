package com.example.demo;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class SampleService {
	
	@Secured("user")
	public String getUsername() {
	    SecurityContext securityContext = SecurityContextHolder.getContext();
	    return securityContext.getAuthentication().getName();
	}
	
	@Secured({ "user", "admin" })
	public String someOtherMethod() {
	    return "Some method...";
	}
	
	@PreAuthorize("hasRole('admin')")
	public String getUsernameInUpperCase() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
	    return securityContext.getAuthentication().getName();
	}
	
	
	
}
