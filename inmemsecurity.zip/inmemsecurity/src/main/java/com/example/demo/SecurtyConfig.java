package com.example.demo;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
public class SecurtyConfig extends WebSecurityConfigurerAdapter {
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication()
		.withUser("banu")
		.password("{noop}prakash")
		.roles("admin")
		.and()
		.withUser("test")
		.password("{noop}test")
		.roles("user");
				
	}
	
	/*
	 @Bean public PasswordEncoder getPasswordEncoder() { 
	 	return NoOpPasswordEncoder.getInstance(); 
	 }
	 */
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			.antMatchers("/admin")
			.hasRole("admin")
			.antMatchers("/user")
			.hasAnyRole("user","admin")
			.antMatchers("/").permitAll()
			.and()
			.formLogin();
	}
	
	
}
