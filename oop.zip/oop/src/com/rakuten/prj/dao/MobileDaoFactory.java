package com.rakuten.prj.dao;

import java.util.ResourceBundle;

public class MobileDaoFactory {
	private static String NAME = "";

	// code in static block
	// only once it executes
	static {
		ResourceBundle res = ResourceBundle.getBundle("config");
		NAME = res.getString("MOBILE_DAO");
	}

	public static MobileDao getMobileDao() {
//		return new MobileDaoMongoImpl();
		try {
			return (MobileDao) Class.forName(NAME).newInstance();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
