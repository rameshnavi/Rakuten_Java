package com.rakuten.prj.dao.impl;

import com.rakuten.prj.dao.MobileDao;
import com.rakuten.prj.entity.Mobile;

public class MobileDaoMongoImpl implements MobileDao {

	@Override
	public void addMobile(Mobile m) {
		System.out.println(m.getName() + " stored in mongodb!!!");
	}

}
