package com.rakuten.prj.dao.impl;

import com.rakuten.prj.dao.MobileDao;
import com.rakuten.prj.entity.Mobile;

//Realizes the interface
public class MobileDaoSqlImpl implements MobileDao {

	@Override
	public void addMobile(Mobile m) {
		System.out.println(m.getName() + " stored in database!!!");
	}

}
