package com.rakuten.prj.dao;

import com.rakuten.prj.entity.Mobile;

public interface MobileDao {
	 void addMobile(Mobile m);
}
