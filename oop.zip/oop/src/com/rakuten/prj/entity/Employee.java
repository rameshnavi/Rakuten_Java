package com.rakuten.prj.entity;

public class Employee implements Comparable {
	// fields 
	// other stuff
	@Override
	public int compareTo(Object o) {
		return 0;
	}
	
}
