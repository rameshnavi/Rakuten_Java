package com.rakuten.prj.client;

import com.rakuten.prj.dao.MobileDao;
import com.rakuten.prj.dao.MobileDaoFactory;
import com.rakuten.prj.entity.Mobile;

//OCP
public class MobileClient {

	public static void main(String[] args) {
		Mobile m = new Mobile(1,"iPhone XR", 45000.00,"4G");
//		MobileDao dao = new MobileDaoSqlImpl();
		MobileDao dao =  MobileDaoFactory.getMobileDao();
		dao.addMobile(m);
	}

}
