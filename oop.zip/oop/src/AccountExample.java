
public class AccountExample {

	public static void main(String[] args) {
		Account first = new Account(500); // new is like malloc, dynamic memory allocation
		Account sec = new Account();
		first.deposit(5000); // ctx.message(parameter) ==> deposit(first, 5000)
		sec.deposit(3000); // deposit(second, 3000);
		
		
		System.out.println(first.getBalance());
		System.out.println(sec.getBalance());
		
		Account rahulAcc = new Account(); // count should be 3
		
		 // System.out.println(rahulAcc.getCount()); // 3
		System.out.println(Account.getCount()); 
	}

}
