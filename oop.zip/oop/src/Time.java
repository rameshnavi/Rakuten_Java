
public class Time {
	private int hours;
	private int min;
	
	public Time() {
	}

	public Time(int hours, int min) {
		this.hours = hours;
		this.min = min;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}
	
	public static Time add(Time t1, Time t2) {
        int totalMin = t1.getMin() + t2.getMin();
        int totalHours = t1.getHours() + t2.getHours();

        if (totalMin > 59) {
            totalHours += totalMin / 60;
            totalMin = totalMin % 60;
        }

        if (totalHours > 23) {
            totalHours = totalHours % 24;
        }

        return new Time(totalHours, totalMin);
    }
	
	// a.equals(b) ==> a is "this"; b is passed as "obj"
	@Override
	public boolean equals(Object obj) {
		 Time other = (Time) obj;
		 if(this.hours == other.hours && this.min == other.min) {
			 return true;
		 }
		 return false;
	}
	
	@Override
	public String toString() {
		return "[" + this.hours + " : " + this.min + "]";
	}
}
