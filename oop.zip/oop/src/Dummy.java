
public class Dummy {

	public static void main(String[] args) {
		System.out.println("Hello");
		doTask();
		System.out.println("Bye"); // never executed
	}

	private static void doTask() {
		int x = 10;
		int y = 0;
		if(y != 0)
		System.out.println("Result : " + (x/y));
	}
	
	
}
