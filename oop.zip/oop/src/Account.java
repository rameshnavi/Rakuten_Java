
public class Account {
	private double balance; //state ==> instance variables
	private static int count; // static makes the member class variable not instance
	
	//default --> NoArgs
	public Account() {
		count++;
		balance = 1000;
	}
	
	// Parameterized
	public Account(double amt) {
		count++;
		balance += amt;
	}
	
	public void deposit(double amt) {
		balance += amt;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public static int getCount() {
		return count;
	}
}
