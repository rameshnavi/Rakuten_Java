
public class TimeExample {

	public static void main(String[] args) {
		Time t1 = new Time(4, 30);
		Time t2 = new Time (3,45);
		
		System.out.println(t1.getHours()  + ": " + t1.getMin()); // 4 : 30
		System.out.println(t2.getHours()  + ": " + t2.getMin()); // 3 : 45
		
		// TASK
		Time t3 = Time.add(t1, t2); // add t1 and t2 and return a new time to t3
		System.out.println(t3.getHours()  + " : " + t3.getMin()); // 8 : 15
		
		
		Time a = new Time(3,15);
		Time b = new Time(3,15);
		
		if(a == b) { // false--> 2 different memory locations
			System.out.println("a and b are same");
		}
		
		// Time class inherited equals from Object class
		if(a.equals(b)) {
			System.out.println("Same content!!!");
		}
		
		System.out.println(t3); // Object as argument ==> [8 : 15] invokes toString()
	}

}
