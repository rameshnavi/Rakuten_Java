import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BankingExample {

	public static void main(String[] args) {
		Account acc = new Account(5000.00);
		TransactionThread t1 = new TransactionThread(acc, "A", TransactionType.CREDIT, 2500.00);
		TransactionThread t2 = new TransactionThread(acc, "\tB", TransactionType.DEBIT, 3000.00);
		TransactionThread t3 = new TransactionThread(acc, "\t\tC", TransactionType.CREDIT, 2000.00);
		TransactionThread t4 = new TransactionThread(acc, "\t\t\tD", TransactionType.DEBIT, 2000.00);
		
		ExecutorService service = Executors.newFixedThreadPool(2); // thread pool of size 2
		service.submit(t1);
		service.submit(t2);
		service.submit(t3);
		service.submit(t4);
		
		service.shutdown(); // pool has to be shutdown
		System.out.println("Final Balance : " + acc.getBalance());
	}

}
