import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableFutureExample {

	public static void main(String[] args) {
		ExecutorService ser = Executors.newFixedThreadPool(2);
		Future<Integer> f1 = ser.submit(new Numbers(1, 1000));
		Future<Integer> f2 = ser.submit(new Numbers(900, 1000));
		Future<Integer> f3 = ser.submit(new Numbers(1, 100));
		Future<Integer> f4 = ser.submit(new Numbers(100, 800));
		Future<Integer> f5 = ser.submit(new Numbers(1, 700));
		
		try {
			System.out.println(f1.get());
			System.out.println(f2.get());
			System.out.println(f3.get());
			System.out.println(f4.get());
			System.out.println(f5.get());
		} catch ( Exception e) {
			e.printStackTrace();
		}  
		
		ser.shutdown();
	}

}
